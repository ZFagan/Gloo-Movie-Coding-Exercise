//
//  ViewController.swift
//  GlooMovieExersize2
//
//  Created by ZemoF on 10/31/19.
//  Copyright © 2019 Zemo Fagan. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource{
    @IBOutlet var lblLeft: UILabel!
    @IBOutlet var lblRight: UILabel!
    struct tableCells {
        var theTitle:String
        var thePoster:UIImage
    }
    @IBOutlet var swp: UISwipeGestureRecognizer!
    
    @IBOutlet var backGround: UIView!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var btnLeft: UIButton!
    @IBOutlet var lblInfo: UILabel!
    @IBOutlet var btnRight: UIButton!
    @IBOutlet var imgPoster: UIImageView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var imgPosterInfo: UIImageView!
    @IBOutlet var lblGenres: UILabel!
    @IBOutlet var lblRating: UILabel!
    @IBOutlet var lblRelease: UILabel!
    @IBOutlet var lblPlot: UILabel!
    @IBOutlet var btnCopy: UIButton!
    @IBOutlet var viewBackground: UIView!
    
    var currentDataTitle:[String]=[]
    var currentDataPoster:[String]=[]
    var curentDataLocation:[String]=[]
    var currentDataRating:[String]=[]
    var currentDataReleaseDate:[String]=[]
    var currentDataGenre:[[Int]]=[[]]
    var currentDataPlot:[String]=[]
    var mytime:Timer?=nil
    var selectedCatagory=1
    var dataForCell:[tableCells]=[]
    var selected:Int=0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tblView.backgroundColor=UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 0)
         backGround.backgroundColor=UIColor.init(patternImage: UIImage(named: "movies")!)
        extraInfoPage(hide: true)
        tblView.rowHeight=170
        tblView.transform=CGAffineTransform(rotationAngle: -.pi/2)
        tblView.dataSource=nil
        tblView.delegate=nil
        loadPopularData()
        
        
         
        mytime=Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(initalizetblView(_:)), userInfo: nil, repeats: true)
         
        
    }
    func extraInfoPage(hide:Bool){
        viewBackground.isHidden=hide
        btnCopy.isHidden=hide
        lblPlot.isHidden=hide
        lblTitle.isHidden=hide
        lblGenres.isHidden=hide
        lblRating.isHidden=hide
        lblRelease.isHidden=hide
        imgPosterInfo.isHidden=hide
    }
    @objc func initalizetblView(_:Any){
    if(currentDataTitle.count>5){
        fillStruct()
        tblView.dataSource=self
        tblView.delegate=self
        tblView.reloadData()
         currentDataGenre.removeFirst()
        print(currentDataGenre)
        print(currentDataRating)
        
        print(currentDataReleaseDate)
        
        
        print(currentDataTitle.count)
       mytime!.invalidate()
        
    }else{print("time on")}
   
    }
    func loadPopularData(){
        currentDataTitle=[]
        currentDataPoster=[]
        curentDataLocation=[]
        currentDataRating=[]
        currentDataReleaseDate=[]
        currentDataGenre=[[]]
        currentDataPlot=[]
        let json: [String: Any] = ["title": "ABC",
                                               "dict": ["1":"First", "2":"Second"]]

                    let jsonData = try? JSONSerialization.data(withJSONObject: json)

                    // create post request
                    let url = URL(string: "https://api.themoviedb.org/3/movie/popular?page=1&language=en-US&api_key=cbe2f6a4af65192df60aa122cdb2a204")!
                    var request = URLRequest(url: url)
                    request.httpMethod = "POST"

                    // insert json data to the request
                    request.httpBody = jsonData

                    let task = URLSession.shared.dataTask(with: request) { data, response, error in
                        guard let data = data, error == nil else {
                            print(error?.localizedDescription ?? "No data")
                            return
                        }
                        let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                        if let responded = responseJSON as? [String: Any] {
                           if let nextDeeper = responded["results"] as? [Any] {
                               print("This Worked")
                               for o in 0...19{
                                   if let evenDeeper = nextDeeper[o] as? [String: Any] {
                                                              print("and again")
                                       self.currentDataTitle.append(evenDeeper["title"]! as! String)
                                       self.currentDataPoster.append(evenDeeper["poster_path"] as! String)
                                   // self.currentDataRating.append(evenDeeper["vote_average"] as! String)
                                    if let mynumber:Float=evenDeeper["vote_average"] as? Float {
                                        print(mynumber)
                                    }else{ print("Float Fail")}
                                    if let mynumber:Decimal=evenDeeper["vote_average"] as? Decimal {
                                                                           print(mynumber)
                                                                       }else{ print("Decimal Fail")}
                                    if let mynumber:String=evenDeeper["vote_average"] as? String {
                                                                          print(mynumber)
                                                                      }else{ print("String Fail")}
                                                                      if let mynumber:double_t=evenDeeper["vote_average"] as? double_t {
                                                                                                             print(mynumber)
                                                                        self.currentDataRating.append(String(mynumber))
                                                                                                         }else{ print("double_t Fail")}
                                    let ident=evenDeeper["id"] as! Int
                                    self.currentDataReleaseDate.append(evenDeeper["release_date"] as! String)
                                    self.curentDataLocation.append(String(ident))
                                    self.currentDataPlot.append(evenDeeper["overview"] as! String)
                                    self.currentDataGenre.append(evenDeeper["genre_ids"] as! [Int])
                                                          }else{print("Fail Again")}
                            }
                           }else{print("fail")}
                           print("yay")
                            
                        }
                       
                    
                        print(self.currentDataTitle)
                    }
            

                    task.resume()
              
              
                      
    }
    func loadComingSoonData(){
        currentDataTitle=[]
              currentDataPoster=[]
              curentDataLocation=[]
              currentDataRating=[]
              currentDataReleaseDate=[]
              currentDataGenre=[[]]
              currentDataPlot=[]
        let json: [String: Any] = ["title": "ABC",
                                                      "dict": ["1":"First", "2":"Second"]]

                           let jsonData = try? JSONSerialization.data(withJSONObject: json)

                           // create post request
                           let url = URL(string: "https://api.themoviedb.org/3/movie/upcoming?page=1&language=en-US&api_key=cbe2f6a4af65192df60aa122cdb2a204")!
                           var request = URLRequest(url: url)
                           request.httpMethod = "POST"

                           // insert json data to the request
                           request.httpBody = jsonData

                           let task = URLSession.shared.dataTask(with: request) { data, response, error in
                               guard let data = data, error == nil else {
                                   print(error?.localizedDescription ?? "No data")
                                   return
                               }
                               let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                               if let responded = responseJSON as? [String: Any] {
                                  if let nextDeeper = responded["results"] as? [Any] {
                                      print("This Worked")
                                      for o in 0...19{
                                          if let evenDeeper = nextDeeper[o] as? [String: Any] {
                                                                     print("and again")
                                              self.currentDataTitle.append(evenDeeper["title"]! as! String)
                                              self.currentDataPoster.append(evenDeeper["poster_path"] as! String)
                                            self.currentDataReleaseDate.append(evenDeeper["release_date"] as! String)
                                           if let mynumber:Float=evenDeeper["vote_average"] as? Float {
                                               print(mynumber)
                                           }else{ print("Float Fail")}
                                           if let mynumber:Decimal=evenDeeper["vote_average"] as? Decimal {
                                                                                  print(mynumber)
                                                                              }else{ print("Decimal Fail")}
                                           if let mynumber:String=evenDeeper["vote_average"] as? String {
                                                                                 print(mynumber)
                                                                             }else{ print("String Fail")}
                                                                             if let mynumber:double_t=evenDeeper["vote_average"] as? double_t {
                                                                                                                    print(mynumber)
                                                                               self.currentDataRating.append(String(mynumber))
                                                                                                                }else{ print("double_t Fail")}
                                           let ident=evenDeeper["id"] as! Int
                                           self.curentDataLocation.append(String(ident))
                                           self.currentDataPlot.append(evenDeeper["overview"] as! String)
                                           self.currentDataGenre.append(evenDeeper["genre_ids"] as! [Int])
                                                                 }else{print("Fail Again")}
                                   }
                                  }else{print("fail")}
                                  print("yay")
                               }
                           }
                   

                           task.resume()
                     
                     
                             
    }
    func loadTopRatedData(){
        currentDataTitle=[]
              currentDataPoster=[]
              curentDataLocation=[]
              currentDataRating=[]
              currentDataReleaseDate=[]
              currentDataGenre=[[]]
              currentDataPlot=[]
        let json: [String: Any] = ["title": "ABC",
                                                      "dict": ["1":"First", "2":"Second"]]

                           let jsonData = try? JSONSerialization.data(withJSONObject: json)

                           // create post request
                              let url = URL(string: "https://api.themoviedb.org/3/movie/top_rated?page=1&language=en-US&api_key=cbe2f6a4af65192df60aa122cdb2a204")!
                           var request = URLRequest(url: url)
                           request.httpMethod = "POST"

                           // insert json data to the request
                           request.httpBody = jsonData

                           let task = URLSession.shared.dataTask(with: request) { data, response, error in
                               guard let data = data, error == nil else {
                                   print(error?.localizedDescription ?? "No data")
                                   return
                               }
                               let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                               if let responded = responseJSON as? [String: Any] {
                                  if let nextDeeper = responded["results"] as? [Any] {
                                      print("This Worked")
                                      for o in 0...19{
                                          if let evenDeeper = nextDeeper[o] as? [String: Any] {
                                                                     print("and again")
                                              self.currentDataTitle.append(evenDeeper["title"]! as! String)
                                              self.currentDataPoster.append(evenDeeper["poster_path"] as! String)
                                          // self.currentDataRating.append(evenDeeper["vote_average"] as! String)
                                           if let mynumber:Float=evenDeeper["vote_average"] as? Float {
                                               print(mynumber)
                                           }else{ print("Float Fail")}
                                           if let mynumber:Decimal=evenDeeper["vote_average"] as? Decimal {
                                                                                  print(mynumber)
                                                                              }else{ print("Decimal Fail")}
                                           if let mynumber:String=evenDeeper["vote_average"] as? String {
                                                                                 print(mynumber)
                                                                             }else{ print("String Fail")}
                                                                             if let mynumber:double_t=evenDeeper["vote_average"] as? double_t {
                                                                                                                    print(mynumber)
                                                                               self.currentDataRating.append(String(mynumber))
                                                                                                                }else{ print("double_t Fail")}
                                           let ident=evenDeeper["id"] as! Int
                                           self.curentDataLocation.append(String(ident))
                                           self.currentDataPlot.append(evenDeeper["overview"] as! String)
                                           self.currentDataGenre.append(evenDeeper["genre_ids"] as! [Int])
                                            self.currentDataReleaseDate.append(evenDeeper["release_date"] as! String)
                                            
                                                                 }else{print("Fail Again")}
                                   }
                                  }else{print("fail")}
                                  print("yay")
                               }
                           }
                   

                           task.resume()
                     
                     
                             
    }


    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentDataTitle.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "reuse") as! TableViewCell
        print(dataForCell)
        cell.lbl.text=dataForCell[indexPath.row].theTitle
               cell.lbl.textAlignment=NSTextAlignment.center
               cell.lbl.center=CGPoint(x: 340, y: 100)
        cell.lbl.numberOfLines=3
               cell.lbl?.transform=CGAffineTransform(rotationAngle: .pi/2)
        cell.img?.image=dataForCell[indexPath.row].thePoster
               cell.img?.transform=CGAffineTransform(rotationAngle: .pi/2)
               cell.img.center=CGPoint(x: 150, y: 100)
               tblView.rowHeight=200
        
        
        cell.backgroundColor=UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 0.7)
        cell.lbl.textColor=UIColor.init(displayP3Red: 115/255, green: 253/255, blue: 1, alpha: 1)
               return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        informationScreen(dataAt: indexPath.row)
    }
    func fillStruct(){
        dataForCell=[]
        for q in 0...19{
            let url = URL(string: "https://image.tmdb.org/t/p/w500/"+currentDataPoster[q])
            let data = try? Data(contentsOf: url!)

            if let imageData = data {
                let image = UIImage(data: imageData)
                dataForCell.append(tableCells(theTitle: currentDataTitle[q], thePoster: image!))
            }else{
                print("Not Working")
            }
          
            
        }
    }
    func informationScreen(dataAt:Int){
        extraInfoPage(hide: false)
        lblPlot.text=currentDataPlot[dataAt]
        lblTitle.text=currentDataTitle[dataAt]
        var genreText:String="Genre: "
        //print(currentDataGenre[dataAt])
        for i in 0...currentDataGenre[dataAt].count-1{
            switch currentDataGenre[dataAt][i] {
                    case 28:
                genreText+="Action"
                    case  12:
                 genreText+="Adventure"
                    case  16:
                 genreText+="Animation"
                    case  35:
                 genreText+="Comedy"
                    case  80:
                 genreText+="Crime"
                    case  99:
                 genreText+="Documentary"
                    case  18:
                 genreText+="Drama"
                    case  10751:
                 genreText+="Family"
                    case  14:
                 genreText+="Fantasy"
                    case  36:
                 genreText+="History"
                    case  27:
                 genreText+="Horror"
                    case  10402:
                 genreText+="Music"
                    case  9648:
                 genreText+="Mystery"
                    case  10749:
                 genreText+="Romance"
                    case  878:
                 genreText+="Science Fiction"
                    case  10770:
                 genreText+="TV Movie"
                    case  53:
                 genreText+="Thriller"
                    case  10752:
                 genreText+="War"
                    case  37:
                 genreText+="Western"
                    
            default:
                 genreText+="Problem"
            }
            if i<currentDataGenre[dataAt].count-1{
                genreText+=", "
            }
        }
        lblGenres.text=genreText
        if(currentDataRating[dataAt] == "0.0"){
            lblRating.text="Rating: Not Yet Released"
        }else{
             lblRating.text="Rating: "+currentDataRating[dataAt]+"/10"
        }
       
        lblRelease.text="Release Date: "+currentDataReleaseDate[dataAt]
       let url = URL(string: "https://image.tmdb.org/t/p/w500/"+currentDataPoster[dataAt])
       let data = try? Data(contentsOf: url!)

       if let imageData = data {
           let image = UIImage(data: imageData)
           imgPosterInfo.image=image
       }else{
           print("Not Working")
       }
        selected=dataAt
        
        
    }
    @IBAction func btnLeft(_ sender: Any) {
        
        if(selectedCatagory==1){
            //leftbtn should read Coming Soon
            //rightbtn should read Top Rated
            selectedCatagory=2
            loadComingSoonData()
            lblLeft.text="Most Popular"
            backGround.backgroundColor=UIColor.init(patternImage: UIImage(named: "theater")!)
            lblInfo.text="Currently viewing: Coming Soon.\nSelect title for more information."
            
            
            
        }else if(selectedCatagory==2){
            //btnLeft should read Most Popular
            // btnRight should read Top Rated
            selectedCatagory=1
            loadPopularData()
            lblLeft.text="Coming Soon"
            backGround.backgroundColor=UIColor.init(patternImage: UIImage(named: "movies")!)
            lblInfo.text="Currently viewing: Most Popular.\nSelect title for more information."
        }else{
            //btnLeft should read ComingSoon
            //btnRight should read Most Popular
            selectedCatagory=2
            loadComingSoonData()
            lblLeft.text="Most Popular"
            lblRight.text="Top Rated"
            backGround.backgroundColor=UIColor.init(patternImage: UIImage(named: "theater")!)
            lblInfo.text="Currently viewing: Coming Soon.\nSelect title for more information."
            
        }
       Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { timer in
        print((self.currentDataTitle))
        self.fillStruct()
        self.tblView.reloadData()
        self.currentDataGenre.removeFirst()
        }
        
        
    }
    
    @IBAction func btnRight(_ sender: Any) {
        if(selectedCatagory==1){
            //leftbtn should read Coming Soon
            //rightbtn should read Top Rated
            selectedCatagory=3
            loadTopRatedData()
            lblInfo.text="Currently viewing: Top Rated.\nSelect title for more information."
            lblRight.text="Most Popular"
            backGround.backgroundColor=UIColor.init(patternImage: UIImage(named: "walk")!)
            
        }else if(selectedCatagory==2){
            //btnLeft should read Most Popular
            // btnRight should read Top Rated
            selectedCatagory=3
            loadPopularData()
            lblLeft.text="Coming Soon"
            lblRight.text="Most Popular"
            backGround.backgroundColor=UIColor.init(patternImage: UIImage(named: "walk")!)
            lblInfo.text="Currently viewing: Top Rated.\nSelect title for more information."
        }else{
            //btnLeft should read ComingSoon
            //btnRight should read Most Popular
            selectedCatagory=1
            loadPopularData()
            lblLeft.text="Coming Soon"
            lblRight.text="Top Rated"
            backGround.backgroundColor=UIColor.init(patternImage: UIImage(named: "movies")!)
            lblInfo.text="Currently viewing: Most Popular.\nSelect title for more information."
            
        }
        Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { timer in
        print((self.currentDataTitle))
        self.fillStruct()
        self.tblView.reloadData()
            self.currentDataGenre.removeFirst()
        }
       
    }
    
    @IBAction func close(_ sender: Any) {
        extraInfoPage(hide: true)
    }
    
    @IBAction func btnCopy(_ sender: Any) {
        UIPasteboard.general.string="https://www.themoviedb.org/movie/"+curentDataLocation[selected]
    }
    
}

